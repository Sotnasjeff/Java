package faculdade;

public abstract interface Nota {
    
    public abstract boolean registrar(double nota);
    
    public abstract boolean corrigir(double nota,Aluno x);
    
    public abstract double calcularmedia();

}
