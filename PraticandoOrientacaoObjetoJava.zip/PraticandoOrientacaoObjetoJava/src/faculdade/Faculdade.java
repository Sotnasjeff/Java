package faculdade;

public class Faculdade {

    public static void main(String[] args) {
        Aluno aluno1=new Aluno(24,"904.566.985-96");
        aluno1.setNome("Laranjo da Silva");
        aluno1.setId(2555);
        String nome= aluno1.getNome();
        
    }
    
}
