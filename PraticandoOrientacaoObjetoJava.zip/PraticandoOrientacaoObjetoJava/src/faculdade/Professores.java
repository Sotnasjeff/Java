package faculdade;

public class Professores extends Identificacao {
    private String formacao;
    private String materias;
    
    public Professores(int idade, String cpf){
        super(idade,cpf);
    }

    @Override
    public int getId() {
         if(super.id>9999){
            System.out.println("Voce e um professor");
            return super.id;
        }
        else{
            System.out.println("Id invalido");
            return super.id;
        }
        
    } 
    
    public void setFormacao(int formacao) {
        if(formacao==0){
            this.formacao="Especialista";
        }
        else if(formacao==1){
            this.formacao="Mestre";
        }
        else if(formacao==2){
            this.formacao="Doutorado";
        }
        else{
            this.formacao="Livre-docencia";
        }
    }

    public String getFormacao() {
        return formacao;
    }

    public void setMaterias(int materias) {
        if(materias==0){
           this.materias="Engenharia de Software";
        }
        else if(materias==1){
            this.materias="Linguagem de Programação";
        }
        else if(materias==2){
            this.materias="Estrutura de dados";
        }
        else{
            this.materias="Arquitetura de Hardware";
        }
    }

    public String getMaterias() {
        return materias;
    }
   
}
