package faculdade;

public abstract class Identificacao {
    protected int id;
    private String nome;
    private int idade;
    private String cpf;
    
    public Identificacao(int idade,String cpf){
        this.idade=idade;
        this.cpf=cpf;
    }

    public abstract int getId();

    public void setId(int id) {
        this.id = id;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getNome() {
        return nome;
    }

    public int getIdade() {
        return idade;
    }

    public String getCpf() {
        return cpf;
    }
    
    
}
