package faculdade;

public class Aluno extends Identificacao implements Nota{
    private String curso;
    private double nota;
    private double media;
    
    @Override
    public int getId() {
         if(super.id<9999){
            System.out.println("Voce e um Aluno");
            return super.id;
        }
        else{
            System.out.println("Id invalido");
            return super.id;
        }
        
    } 
    
    public Aluno (int idade,String cpf){
        super(idade,cpf);
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }

    public String getCurso() {
        return curso;
    }

    @Override
    public boolean corrigir(double nota,Aluno x) {
        if(nota<10 || nota>0){
            x.registrar(nota);
            return true;
        }
        else{
            System.out.println("Você precisa digitar uma nota que seja entre 0 a 10");
            return false;
        }
    }

    @Override
    public double calcularmedia() {
        this.media=this.nota;
        if(this.media/3>=6){
            System.out.println("Parabens, voce passou!");
            System.out.println("Sua media foi:");
            return this.media;
        }
        else if(this.media/3>=3){
            System.out.println("Você foi para exame, dá para recuperar");
            System.out.println("Sua media foi:");
            return this.media;
        }
        else{
            System.out.println("Você foi reprovado!");
            System.out.println("Sua media foi:");
            return this.media;
        }
    }

    @Override
    public boolean registrar(double nota) {
        if(nota<10 || nota>0){
            this.nota+=nota;
            return true;
        }
        else{
            System.out.println("Você precisa digitar uma nota que seja entre 0 a 10");
            return false;
        }
    }
       
}
