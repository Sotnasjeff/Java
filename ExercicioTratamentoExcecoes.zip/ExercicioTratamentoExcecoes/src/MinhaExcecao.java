public class MinhaExcecao extends Exception {
    
    MinhaExcecao(String mensagem){
        super(mensagem);
    }
}
