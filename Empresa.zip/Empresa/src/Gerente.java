

public class Gerente extends Funcionario implements Autenticavel{
    
    private int senha;
    
    public double getbonificacao(){
        return super.getSalario();
    }

    @Override
    public boolean autenticar(int password) {
        if(this.senha==password){
            return true;
        }
        else{
            return false;
        }
    }

    @Override
    public void setSenha(int Senha) {
        this.senha=Senha;
    }
    
    
   
    
    
}
