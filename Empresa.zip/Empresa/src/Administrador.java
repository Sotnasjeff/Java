

public class Administrador extends Funcionario implements Autenticavel {

    private AutenticacaoUtil util;
    
    public Administrador(){
        this.util=new AutenticacaoUtil();
    }
    
    @Override
    public double getbonificacao() {
        return 0;
    }

    @Override
    public void setSenha(int Senha) {
        this.util.setSenha(Senha);
    }

    @Override
    public boolean autenticar(int password) {
        boolean autenticou=this.util.autenticar(password);
        return autenticou;
    }
    
}
