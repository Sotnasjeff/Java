

public class ControleBonus {
    private double soma;
    
    public void bonus(Funcionario f){
        double bonus= f.getbonificacao();
        this.soma+=bonus;
    }

    public double getSoma() {
        return soma;
    }
   
    
}
