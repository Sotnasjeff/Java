

public class SistemaInterno {
    private int senha=2222;
    
    public void autentica(Autenticavel g){
        boolean autenticado=g.autenticar(this.senha);
        if(autenticado){
            System.out.println("Você pode entrar no sistema");
        }
        else{
            System.out.println("Acesso negado");
        }
    }
    
}
