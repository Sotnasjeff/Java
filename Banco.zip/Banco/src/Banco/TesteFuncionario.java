package Banco;

public class TesteFuncionario {
    
    public static void main(String[] args) {

        
        Gerente Luis= new Gerente();
        Luis.setSenha(2232);
        
        SistemaInterno si= new SistemaInterno();
        si.autentica(Luis);
        
        Administrador adm= new Administrador ();
        adm.setSenha(3333);
        si.autentica(adm);
        
        
    }
}
