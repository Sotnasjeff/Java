package Banco;

public abstract interface Tributavel {
    
    public abstract double getValorImposto();

}
