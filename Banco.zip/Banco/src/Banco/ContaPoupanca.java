package Banco;

public class ContaPoupanca extends Conta {
    
    public ContaPoupanca(int agencia, int numero){
        super(agencia,numero);
    }

    @Override
    public void depositar(double valor) {
        super.saldo+=valor;
    }
    
    @Override
    public void retirar(double valor)throws SaldoInsuficienteException {
        if(super.saldo<valor){
            throw new SaldoInsuficienteException("Saldo:"+super.saldo+"é menor que o valor:"+valor);
        }
        super.saldo-=valor;
    }
        
}
