package Banco;

public abstract interface Autenticavel {
    

    public abstract boolean autenticar(int password);
    
    public abstract void setSenha(int Senha);
    
}
