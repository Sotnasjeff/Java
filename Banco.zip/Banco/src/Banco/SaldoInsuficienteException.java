package Banco;

public class SaldoInsuficienteException extends Exception {
    
    SaldoInsuficienteException(String msg){
        super(msg);
    }
}
