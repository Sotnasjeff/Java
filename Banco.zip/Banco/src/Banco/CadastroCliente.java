package Banco;

public class CadastroCliente {

    public static void main(String[] args) {
        Cliente jefferson= new Cliente();
            jefferson.setNome("Jefferson Santos");
            jefferson.setCpf("409.120.498-80");
            jefferson.setProfissão("Desenvolvedor Back-End");
            
     
        
    }
    
}
