package Banco;

public class CalculadorImposto {
    private int valorimposto;
    
    public void valoresimposto(Tributavel contas){
        double valor=contas.getValorImposto();
        this.valorimposto+=valor;
    }

    public double getValorimposto() {
        return valorimposto;
    }
    
}
