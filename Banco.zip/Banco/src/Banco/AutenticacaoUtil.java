package Banco;

public class AutenticacaoUtil {
    private int senha;
    
    public void setSenha(int Senha) {
        this.senha=Senha;
    }

    public boolean autenticar(int password) {
        if(password==this.senha){
            return true;
        }
        else{
            return false;
        }
    }

    
}
