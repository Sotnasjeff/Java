package Banco;

public class TesteReferencias {
    
    public static void main(String[] args) {
            
        Gerente quatroberto= new Gerente();
            quatroberto.setSalario(12500);

        ControleBonus controle= new ControleBonus();
            controle.bonus(quatroberto);
        
            System.out.println(controle.getSoma());
            

        
    }
    
}
