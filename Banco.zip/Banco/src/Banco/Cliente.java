package Banco;

public class Cliente implements Autenticavel {
    private String nome;
    private String cpf;
    private String profissão;
    private AutenticacaoUtil util;
    
    public Cliente() {
        this.util= new AutenticacaoUtil();
    }


    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getProfissão() {
        return profissão;
    }

    public void setProfissão(String profissão) {
        this.profissão = profissão;
    }

    @Override
    public void setSenha(int Senha) {
        this.util.setSenha(Senha);
    }

    @Override
    public boolean autenticar(int password) {
        return this.util.autenticar(password);
        }
            
}
    

