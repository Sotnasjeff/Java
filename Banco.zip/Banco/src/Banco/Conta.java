package Banco;

public abstract class Conta {
    protected double saldo;
    private int agencia;
    private int numero;
    private Cliente titular;
    private static int total;
    
public Conta(int agencia, int numero){
    Conta.total++;
    System.out.println("O total de conta é: " +total);
    if(agencia<=0){
        System.out.println("Você não pode digitar numero menor que 0"); 
        
    }
    this.agencia=agencia;
    
    if(numero<=0){
        System.out.println("Você não pode digitar numero menor que 0");   
    }
    else{
        this.numero=numero;
    }
    
    System.out.println("Sua conta foi criada com sucesso!");
    System.out.println("O numero da conta é:"+this.numero + "\ne sua agencia é:"+this.agencia);
}
 
    public abstract void depositar(double valor);

    public void retirar(double valor)throws SaldoInsuficienteException{
        if(this.saldo<valor){
            throw new SaldoInsuficienteException("O saldo:"+this.saldo+" é menor que o valor solicitado:"+valor);
        }
        this.saldo-=valor;
    }   
 
    public void transferir(double valor, Conta destino)throws SaldoInsuficienteException{
        this.retirar(valor); 
        destino.depositar(valor);
    }
    
    public double getSaldo(){
        return this.saldo;
    }
    
    public int getNumero(){
        return this.numero;
    }
    
    public void setNumero(int novoNumero){
        this.numero=novoNumero;
    }

    public int getAgencia() {
        return this.agencia;
    }

    public void setAgencia(int agencia) {
        this.agencia = agencia;
    }

    public Cliente getTitular() {
        return titular;
    }

    public void setTitular(Cliente titular) {
        this.titular = titular;
    }

    public static int getTotal() {
        return total;
    }
    
    
    
    
}
