package Banco;

public class ContaCorrente extends Conta implements Tributavel{
    
    public ContaCorrente(int agencia, int numero){
        super(agencia,numero);
    }

    @Override
    public void retirar(double valor)throws SaldoInsuficienteException {
        double imposto= valor+0.20;
        super.retirar(imposto);
    }

    @Override
    public void depositar(double valor) {
        super.saldo+=valor;
    }

    @Override
    public double getValorImposto() {
        double valor=super.saldo*0.20;
        return valor;
    }
    
}
